# Structuration

Cette application est un canevas permettant de commencer une application MicroService REST basée sur SpringBoot.

Elle suit les préconisations de l'architecture logicielle de référence : http://pocconfluencebddfit.dev.echonet/pages/viewpage.action?pageId=90636313

Elle est composée d'un projet parent et de 5 sous-modules :

- Domain
- Application
- Exposition
- Batch
- Infrastructure

La couche exposition utilise [OpenAPI-Spec](https://github.com/swagger-api/swagger-core) et Springfox (https://github.com/springfox/springfox) afin de documenter les services exposés.
(Elle est optionnelle, supprimer ce projet n'expose pas une API)

La couche batch utilise Spring Batch
(Elle est optionnelle, supprimer ce projet si l'application ne comprend pas de batch)

# Packaging

L'artifact produit par le build est un fichier "WAR" déployable sur un serveur liberty core.

# Démarrer l'application

1) Depuis Eclipse sur le projet "Exposition" : Run as java application

	url : http://localhost:8080/T1

2) Sur Liberty core, déposer le war dans le répertoire dropins et relancer le serveur 


# Documentation API
L'interface swagger-ui est visible via l'url : http://localhost:8080/T1/swagger-ui.html

le swagger au format JSON est disponible via cet url : http://localhost:8080/T1/v2/api-docs


# Paramétrage
Les paramètres de l'application (port, contextPath, etc...) peuvent être modifiés dans le fichier application.yml

Ce fichier peut être externalisé sur le serveur Liberty dans un répertoire /config

