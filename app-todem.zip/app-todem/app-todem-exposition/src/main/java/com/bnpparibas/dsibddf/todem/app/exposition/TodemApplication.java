package com.bnpparibas.dsibddf.todem.app.exposition;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@ComponentScan(basePackages = { "com.bnpparibas.dsibddf.todem.app" })
public class TodemApplication {

	/**
	 * Main method used to launch Application with Embeded Tomcat
	 *
	 * @param args
	 * @throws Exception
	 */
	public static void main(final String[] args) throws Exception {
		 SpringApplication.run(TodemApplication.class, args);
	}

}
