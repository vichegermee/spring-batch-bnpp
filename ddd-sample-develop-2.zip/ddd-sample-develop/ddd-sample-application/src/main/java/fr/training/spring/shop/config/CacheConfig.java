package fr.training.spring.shop.config;

import org.springframework.cache.annotation.EnableCaching;

@EnableCaching
public class CacheConfig {

}
